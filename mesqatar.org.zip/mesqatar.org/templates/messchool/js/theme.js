/* Copyright (C) YOOtheme GmbH, http://www.gnu.org/licenses/gpl.html GNU/GPL */

jQuery(function($) {

    var config = $('html').data('config') || {};

    // Social buttons
    $('article[data-permalink]').socialButtons(config);

    
// 	Counter on home page
	$('.counter').appear();
	$(document.body).on('appear', '.counter', function(e) {
	var $this = $(this),
	countTo = $this.attr('data-count');

	$({ countNum: $this.text()}).animate({
	countNum: countTo
	}, {
	duration: 3000,
	easing:'linear',
	step: function() {
	$this.text(Math.floor(this.countNum));
	},
	complete: function() {
	$this.text(this.countNum);
	}
	});
	});
// 	END Counter
	
});
